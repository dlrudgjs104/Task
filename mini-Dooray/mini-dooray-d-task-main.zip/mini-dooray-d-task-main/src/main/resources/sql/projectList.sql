insert into `project` (`project_name`, `project_status`)
values ('projectTest1', 'active'),
       ('projectTest2', 'dormant'),
       ('projectTest3', 'active'),
       ('projectTest4', 'ended'),
       ('projectTest5', 'active'),
       ('projectTest6', 'dormant'),
       ('projectTest7', 'active'),
       ('projectTest8', 'active'),
       ('projectTest9', 'ended'),
       ('projectTest10', 'active');
