package com.nhnacademy.accountapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
