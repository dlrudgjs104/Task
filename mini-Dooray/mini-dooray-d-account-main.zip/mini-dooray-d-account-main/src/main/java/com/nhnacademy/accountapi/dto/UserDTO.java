package com.nhnacademy.accountapi.dto;

public record UserDTO(String email, String password) {
}
