# 소나큐브
- 소나큐브 에러로 인해 jacoco. index.html 첨부합니다.

![SonarQube.png](SonarQube.png)