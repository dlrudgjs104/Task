package com.nhnacademy.minidooraydgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniDoorayDGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
